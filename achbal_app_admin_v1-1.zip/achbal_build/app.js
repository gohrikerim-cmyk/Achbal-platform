const starterPosts = [
 {id:1,category:"news",label:"خبر",title:"مرحباً بكم في منصة أشبال",body:"هذه مساحة أخبار جمعية أشبال للتوعية والتثقيف. يمكنك إضافة المنشورات من لوحة الإدارة.",date:"النسخة التجريبية"},
 {id:2,category:"activities",label:"أنشطة",title:"برامج وأنشطة الجمعية",body:"تابعوا الأنشطة الثقافية والتوعوية والرياضية والمبادرات المجتمعية.",date:"قسم الأنشطة"},
 {id:3,category:"announcements",label:"إعلان",title:"الإعلانات والتنبيهات",body:"ستُنشر هنا مواعيد الفعاليات والاجتماعات وفرص المشاركة.",date:"قسم الإعلانات"}
];
const storageKey="achbal_posts_v1";
let posts;
try { posts=JSON.parse(localStorage.getItem(storageKey)) || starterPosts; } catch { posts=starterPosts; }
const labels={news:"خبر",activities:"أنشطة",announcements:"إعلان"};
const postsEl=document.getElementById("posts");
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function save(){localStorage.setItem(storageKey,JSON.stringify(posts));}
function render(filter="all"){
 const list=filter==="all"?posts:posts.filter(p=>p.category===filter);
 postsEl.innerHTML=list.map(p=>`<article class="post"><span class="tag">${labels[p.category]||"منشور"}</span><h3>${escapeHTML(p.title)}</h3><p>${escapeHTML(p.body).replace(/\n/g,"<br>")}</p><span class="date">${escapeHTML(p.date)}</span></article>`).join("")||'<div class="empty">لا توجد منشورات في هذا القسم حالياً.</div>';
}
render();
document.querySelectorAll(".quick").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".quick").forEach(b=>b.classList.remove("active"));btn.classList.add("active");render(btn.dataset.filter);}));
document.getElementById("year").textContent=new Date().getFullYear();

// لوحة إدارة محلية: تحفظ المنشورات على هذا المتصفح فقط إلى حين ربط Firebase.
const adminPanel=document.getElementById("adminPanel");
document.getElementById("adminBtn").addEventListener("click",()=>{adminPanel.hidden=!adminPanel.hidden;if(!adminPanel.hidden)renderAdmin();});
document.getElementById("closeAdmin").addEventListener("click",()=>adminPanel.hidden=true);
function renderAdmin(){
 const list=document.getElementById("adminPosts");
 list.innerHTML=posts.map(p=>`<div class="admin-post"><div><strong>${escapeHTML(p.title)}</strong><small>${labels[p.category]} · ${escapeHTML(p.date)}</small></div><button type="button" class="danger" data-delete="${p.id}">حذف</button></div>`).join("")||'<p class="hint-dark">لا توجد منشورات بعد.</p>';
 list.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>{if(confirm("هل تريد حذف هذا المنشور؟")){posts=posts.filter(p=>p.id!==Number(b.dataset.delete));save();render();renderAdmin();}}));
}
document.getElementById("postForm").addEventListener("submit",e=>{
 e.preventDefault();const title=document.getElementById("postTitle").value.trim();const body=document.getElementById("postBody").value.trim();const category=document.getElementById("postCategory").value;
 if(!title||!body)return;
 posts.unshift({id:Date.now(),category,label:labels[category],title,body,date:new Date().toLocaleDateString("ar-MR")});save();render(document.querySelector(".quick.active")?.dataset.filter||"all");e.target.reset();renderAdmin();document.getElementById("adminMessage").textContent="أُضيف المنشور إلى هذا الجهاز.";
});

let deferredPrompt;const installBtn=document.getElementById("installBtn");
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;installBtn.hidden=false;});
installBtn.addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true;});
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
const notifyBtn=document.getElementById("notifyBtn"),notifyStatus=document.getElementById("notifyStatus");
notifyBtn.addEventListener("click",async()=>{if(!("Notification" in window)){notifyStatus.textContent="هذا المتصفح لا يدعم إشعارات الويب.";return;}if(!window.isSecureContext){notifyStatus.textContent="يلزم نشر التطبيق على رابط HTTPS لتفعيل الإشعارات.";return;}const permission=await Notification.requestPermission();if(permission==="granted"){notifyStatus.textContent="تم السماح بالإشعارات على هذا الجهاز. يلزم ربط خدمة الإشعارات لإرسال الأخبار تلقائياً.";new Notification("جمعية أشبال",{body:"تم تفعيل إذن الإشعارات على جهازك."});}else notifyStatus.textContent="لم يتم السماح بالإشعارات.";});
