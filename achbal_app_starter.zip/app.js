const samplePosts = [
 {category:"news", label:"خبر", title:"مرحباً بكم في منصة أشبال", body:"هذه المساحة مخصصة لنشر أخبار جمعية أشبال للتوعية والتثقيف ومستجداتها. ستظهر هنا المنشورات الجديدة بعد إضافتها من لوحة الإدارة.", date:"إطلاق النسخة التجريبية"},
 {category:"activities", label:"أنشطة", title:"برامج وأنشطة الجمعية", body:"تابعوا هنا الأنشطة الثقافية والتوعوية والرياضية والمبادرات المجتمعية التي تنظمها الجمعية.", date:"قسم الأنشطة"},
 {category:"announcements", label:"إعلان", title:"الإعلانات والتنبيهات", body:"سيتم نشر مواعيد الفعاليات والاجتماعات وفرص المشاركة والتكوين عبر هذا القسم.", date:"قسم الإعلانات"}
];
const postsEl = document.getElementById("posts");
function render(filter="all"){
 const list = filter==="all" ? samplePosts : samplePosts.filter(p=>p.category===filter);
 postsEl.innerHTML = list.map(p=>`<article class="post"><span class="tag">${p.label}</span><h3>${p.title}</h3><p>${p.body}</p><span class="date">${p.date}</span></article>`).join("") || '<div class="empty">لا توجد منشورات في هذا القسم حالياً.</div>';
}
render();
document.querySelectorAll(".quick").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".quick").forEach(b=>b.classList.remove("active"));
 btn.classList.add("active"); render(btn.dataset.filter);
}));
document.getElementById("year").textContent = new Date().getFullYear();

let deferredPrompt;
const installBtn=document.getElementById("installBtn");
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;installBtn.hidden=false;});
installBtn.addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true;});

if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
const notifyBtn=document.getElementById("notifyBtn");
const notifyStatus=document.getElementById("notifyStatus");
notifyBtn.addEventListener("click",async()=>{
 if(!("Notification" in window)){notifyStatus.textContent="هذا المتصفح لا يدعم إشعارات الويب.";return;}
 if(!window.isSecureContext){notifyStatus.textContent="يلزم نشر التطبيق على رابط HTTPS لتفعيل الإشعارات.";return;}
 const permission=await Notification.requestPermission();
 if(permission==="granted"){
  notifyStatus.textContent="تم السماح بالإشعارات على هذا الجهاز. يلزم ربط Firebase لتلقي الأخبار الجديدة تلقائياً.";
  new Notification("جمعية أشبال",{body:"تم تفعيل إذن الإشعارات على جهازك."});
 }else{notifyStatus.textContent="لم يتم السماح بالإشعارات. يمكنك تفعيلها لاحقاً من إعدادات المتصفح.";}
});
