import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

// إعدادات Firebase الخاصة بمشروع Achbal Platform التي زوّدنا بها صاحب المشروع.
// هذه القيم تعريفية للواجهة؛ الحماية الفعلية تكون عبر قواعد Realtime Database.
const firebaseConfig = {
  apiKey: 'AIzaSyCkgNTleEFB8i9qZzQnlUd-AAq7qHRMfUQ',
  authDomain: 'achbal-platform.firebaseapp.com',
  databaseURL: 'https://achbal-platform-default-rtdb.firebaseio.com',
  projectId: 'achbal-platform',
  storageBucket: 'achbal-platform.firebasestorage.app',
  messagingSenderId: '649258060753',
  appId: '1:649258060753:web:a4e456ea0779a449b32ef0',
  measurementId: 'G-65F37PJZX5'
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
